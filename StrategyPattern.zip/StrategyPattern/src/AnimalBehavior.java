public interface AnimalBehavior {
    void makeSound();
}
