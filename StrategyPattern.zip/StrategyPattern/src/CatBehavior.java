public class CatBehavior implements AnimalBehavior{

    @Override
    public void makeSound() {
        System.out.println("meow");
    }
}
