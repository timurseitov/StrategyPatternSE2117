public class DogBehavior implements AnimalBehavior{
    @Override
    public void makeSound() {
        System.out.println("bark");
    }
}
