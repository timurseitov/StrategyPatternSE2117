public interface FlyBehavior {
    void fly();
}
